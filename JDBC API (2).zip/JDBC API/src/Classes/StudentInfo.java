package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class StudentInfo {
	
	void addStudent() throws Exception
{

	try
	{
		int id;
		String name,address;
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Student Details....");
		id = sc.nextInt();
		name = sc.next();
		address = sc.next();
		
	{
		Class.forName("org.h2.Driver");
		Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
	    PreparedStatement pst = con.prepareStatement("insert into student values(?,?,?)");
		pst.setInt(1, id);
		pst.setString(2, name);
		pst.setString(3, address);

		pst.executeUpdate();
		pst.close();
		con.close();
		System.out.println("Data is added successfully....");
	  }
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
 }


	public static void main(String[] args) throws Exception
	{

		StudentInfo studentInfo = new StudentInfo();
		studentInfo.addStudent();


	}

}
