package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class StudentInfo {
	
	void addStudent() throws Exception
{

	try

	{
		Class.forName("org.h2.Driver");
		Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
		PreparedStatement pst = con.prepareStatement("insert into student values(107,'Meghna','MVM')");
		pst.executeUpdate();
		pst.close();
		con.close();
		System.out.println("Data is added successfully....");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
 }


	public static void main(String[] args) throws Exception
	{

		StudentInfo studentInfo = new StudentInfo();
		studentInfo.addStudent();


	}

}
